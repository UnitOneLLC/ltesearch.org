<!DOCTYPE html>
<html>
<body>
<?php

	function fetch_api_key($conn, $apiname) {
	    $stmt = $conn->query("select apikey from api where name = '$apiname'");
	    $result = $stmt->fetch(PDO::FETCH_ASSOC);
	    return $result['apikey'];
	}

  	$dbjson = file_get_contents("../etc/ltesearch.org/db.json");
	$dbarr = json_decode($dbjson, TRUE);
  
	$hostname = $dbarr['hostname'];
	$port = $dbarr['port'];
	$dbname = $dbarr['dbname'];
	$username = $dbarr['username'];
	$password = $dbarr['password'];

	$dbspec = "mysql:host=$hostname;port=$port;dbname=$dbname";
	echo $dbspec; echo "<br>$password<br>";

try {
    $conn = new PDO($dbspec, $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);    
    
	$apikey = fetch_api_key($conn, 'custom_search');
	echo ("the key is $apikey");
    
    
    }
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }  
?>
</body>
</html>
