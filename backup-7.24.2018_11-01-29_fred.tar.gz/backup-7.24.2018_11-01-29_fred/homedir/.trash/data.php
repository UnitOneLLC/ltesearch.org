<?php

	/*
	 * Get a connection to the lte search database. Returns null on failure.
	 */
	function db_connect() {
		$dbjson = file_get_contents("../etc/ltesearch.org/db.json");
		$dbarr = json_decode($dbjson, TRUE);
  
		$hostname = $dbarr['hostname'];
		$port = $dbarr['port'];
		$dbname = $dbarr['dbname'];
		$username = $dbarr['username'];
		$password = $dbarr['password'];
		$dbspec = "mysql:dbname=$dbname;host=$hostname;port=$port";
		echo $dbspec . "<br>";
		try {
			$conn = new PDO($dbspec, $username, $password);
			$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
			return $conn;
		}
		catch(PDOException $e)
		{
			echo "Connection failed: " . $e->getMessage() . "<br>";
			return null;
		}  
	}

	/* 
	 * Fetch the api key for the named api, using the provided db connection.
	 */
	function fetch_api_key($conn, $apiname) {
	    $stmt = $conn->query("select apikey from api where name = '$apiname'");
	    $result = $stmt->fetch(PDO::FETCH_ASSOC);
	    return $result['apikey'];
	}
	
	/*
	 * checks that the given name is a known region and returns the region id. Returns
	 * null if not found.
	 */
	function validate_region($conn, $region_name) {
		$stmt = $conn->query("select id from regions where name = '$region_name'");
		$result = $stmt->fetch(PDO::FETCH_NUM);
		var_dump($result);
	}
	
	/*
	 * Fetch the set of keywords as an array for the specified topic and region.
	 */
	 function fetch_keywords($conn, $topic, $region_name) {
	 }

?>
