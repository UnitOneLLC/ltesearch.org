<?php
class CustomSearch {
	const HOST_URL = 'https://content.googleapis.com/customsearch/v1';
	const MAX_ITEMS = 10;
	
	protected $_engine_id;
	protected $_search_terms;
	protected $_url_filters;
	protected $_content_filters;
	protected $_apikey;
	
	function __construct($apikey, $engine, $search_terms, $url_filters, $content_filters) {
		$this->_engine_id = $engine;
		$this->_search_terms  = $search_terms;
		$this->_url_filters = $url_filters;
		$this->_content_filters = $content_filters;
		$this->_apikey = $apikey;
	}

	function buildQuery($number, $start_index) {
		$q = self::HOST_URL;
		$q .= '?cx=' . rawurlencode($this->_engine_id);
		$q .= '&key=' . rawurlencode($this->_apikey);
		$q .= '&dateRestrict=d2';
		$q .= '&lr=lang_en';
		$q .= "&num=$number";
		$q .= "&start=$start_index";
		$q .= '&q=' . rawurlencode("");
		$q .= '&orTerms=' . rawurlencode($this->_search_terms);
/*		$q .= '&excludeTerms=' . rawurlencode($this->_excludes); */
		return $q;
	}
	
	function execute_search($max_items) {
	
		$current_index = 1;
		$ret_arr = array();
		
		do {	
			$q = $this->buildQuery(self::MAX_ITEMS, $current_index);
			$curlObj = curl_init();
			curl_setopt($curlObj, CURLOPT_URL, $q);
			curl_setopt($curlObj, CURLOPT_RETURNTRANSFER, TRUE);
			curl_setopt($curlObj, CURLOPT_HTTPGET, TRUE);

			$json = curl_exec($curlObj);

			$result_aa = json_decode($json, TRUE);

			$items = $result_aa["items"];
			if (is_null($items)) {
				break;
			}

			foreach($items as $item) {
				$date_aa = self::estimate_item_date($item);
				
				if (!$this->filter_url($item["link"])) {
					continue;
				}
				
				if (!$this->filter_contents($item["snippet"] . " " . $item['title'])) {
					continue;
				}
				
				$ret_item = array(
					"pubDate" => $date_aa['year'].'-'.$date_aa['month'].'-'.$date_aa['day'],      
					"url" => $item["link"], 
					"title" => $item["title"],
					"description" => $item["htmlSnippet"]);
					
				array_push($ret_arr, $ret_item);
				
				if (count($ret_arr) == $max_items) 
					break;
			}
			$current_index += count($items);
		} while ($current_index < $max_items);

		return $ret_arr;
	}
	
	function filter_url($url) {
		$passes = true;
		$lurl = strtolower($url);
		foreach ($this->_url_filters as &$filter) {
			if (strpos($lurl, $filter) !== false) {
				$passes = false;
				break;
			}
		}
		return $passes;
	}

	function filter_contents($str) {
		$passes = true;
		$lstr = strtolower($str);
		foreach ($this->_content_filters as &$filter) {
			if (strpos($lstr, $filter) !== false) {
				$passes = false;
				break;
			}
		}
		return $passes;
	}
	
	function try_date($aa, $tag, &$date) {
		if (array_key_exists($tag, $aa)) {
			$date = date_parse($aa[$tag]);
			return true;
		}
		else
			return false;
	}
		
	function estimate_item_date($item) {
		if (!array_key_exists("pagemap", $item)) {
			$dt = getdate();
			$dt["day"] = $dt["mday"];
			return $dt;
		}
			
		$pagemap = $item["pagemap"];
		if (array_key_exists("metatags", $pagemap)) {
			$metatags = $pagemap["metatags"][0];
			
			if (self::try_date($metatags, "eomportal-lastupdate", $date))
				return $date;
			if (self::try_date($metatags, "bt:pubdate", $date))
				return $date;
			if (self::try_date($metatags, "pubdate", $date))
				return $date;
			if (self::try_date($metatags, "article_date_original", $date))
				return $date;
			if (self::try_date($metatags, "article:published_time", $date))
				return $date;
		}
		else if (array_key_exists("newsarticle", $pagemap)) {
			$newsarticle = $pagemap["newsarticle"][0];
			
			if (self::try_date($newsarticle, "datepublished", $date))
				return $date;
		}
		else if (array_key_exists("document", $pagemap)) {
			$newsarticle = $pagemap["document"][0];
			
			if (self::try_date($newsarticle, "article_date_original", $date))
				return $date;
		}
		
		$dt = getdate();
		$dt["day"] = $dt["mday"];
		return $dt;
	}
}
